CREATE DATABASE maybank_java_assesment;

USE maybank_java_assesment;

CREATE TABLE hello_world (
    hello_world_id INT AUTO_INCREMENT PRIMARY KEY,
    message VARCHAR(255) NOT NULL
);

INSERT INTO hello_world (message) VALUES ('Hello, World from the Database!');