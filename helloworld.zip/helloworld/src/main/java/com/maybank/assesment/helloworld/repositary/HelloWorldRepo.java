package com.maybank.assesment.helloworld.repositary;

import com.maybank.assesment.helloworld.entity.HelloWorldEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HelloWorldRepo extends JpaRepository <HelloWorldEntity, Integer> {
}

