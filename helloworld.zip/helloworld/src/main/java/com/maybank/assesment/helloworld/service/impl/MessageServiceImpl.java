package com.maybank.assesment.helloworld.service.impl;

import com.maybank.assesment.helloworld.entity.HelloWorldEntity;
import com.maybank.assesment.helloworld.repositary.HelloWorldRepo;
import com.maybank.assesment.helloworld.service.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class MessageServiceImpl implements MessageService {
    @Autowired
    private HelloWorldRepo helloWorldRepo;

    @Override
    public String getMessage() {
        Optional<HelloWorldEntity> message = helloWorldRepo.findById(1); // Assuming the message ID is 1
        return message.map(HelloWorldEntity::getMessage).orElse("No message found");
    }
}
