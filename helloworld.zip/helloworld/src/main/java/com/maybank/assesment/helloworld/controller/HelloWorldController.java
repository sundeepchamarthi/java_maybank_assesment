package com.maybank.assesment.helloworld.controller;

import com.maybank.assesment.helloworld.service.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.ui.Model;

@Controller
public class HelloWorldController {

    @Autowired
    private MessageService messageService;

    @GetMapping("/hello")
    public String hello(Model model) {
        try {
            String message = messageService.getMessage();
            model.addAttribute("message", message);
            return "helloWorld";
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println(e.getMessage());
        }

        return "hello";
    }
}
