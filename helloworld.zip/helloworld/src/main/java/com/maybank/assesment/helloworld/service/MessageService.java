package com.maybank.assesment.helloworld.service;

public interface MessageService {

    String getMessage();
}
