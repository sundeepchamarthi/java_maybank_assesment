package com.maybank.assesment.helloworld.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name= "hello_world")
@Getter
@Setter
public class HelloWorldEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name= "hello_world_id")
    private Integer id;

    @Column(name= "message")
    private String message;

}
