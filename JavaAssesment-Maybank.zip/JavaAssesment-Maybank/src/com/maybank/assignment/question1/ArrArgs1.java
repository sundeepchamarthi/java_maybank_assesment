package com.maybank.assignment.question1;

public class ArrArgs1 {
    // Using try catch enhanced the code insted of infinite loop
    public static void main(String[] args) {
        int k = 0;
        try {
            // Insted of do-while infinite loop check the argument in while loop
            while (k < args.length) {
                System.out.println("Value of input is " + k + " and argument: " + args[k]);
                k++;
            }
            System.exit(1);
        } catch (ArrayIndexOutOfBoundsException errorOC) {
            System.err.println("Error occurred: " + errorOC.toString());
        }
    }
}