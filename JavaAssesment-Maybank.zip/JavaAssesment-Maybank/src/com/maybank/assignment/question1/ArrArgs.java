package com.maybank.assignment.question1;

public class ArrArgs {
    //Enhance without Try catch and removed infinite loop  do-while
    public static void main(String[] args) {
        // Input validation: Ensure args are not empty. If empty exit
        if (args.length == 0) {
            System.err.println("No arguments provided.");
            System.exit(1);  // Exit with a non-zero status code to indicate error
        }
        //Input has Args then proceed with below method.
        processArguments(args);
    }

    private static void processArguments(String[] args) {
        for (int k = 0; k < args.length; k++) {
            // Enhancement: Add space after 'is' and 'and' for readability
            System.out.println("Value of input is " + k + " and argument is " + args[k]);
        }
    }
}




