package com.maybank.assignment.question3;

public class OutofMemoryWithGC {

    public static void main(String[] args) {
        StringBuffer sb = new StringBuffer();
        int i = 0;
        try {
            while (true) {
                //String buffer to append large data
                sb.append("Some large string content to fill the heap memory quickly. ");
                i++;
                if (i % 1000 == 0) {
                    System.gc(); //perform JVM to garbage collection
                }
            }
        } catch (OutOfMemoryError e) {
            System.out.println("OutOfMemoryError occurred after " + i + " iterations.");
            e.printStackTrace();
        }
    }
}
