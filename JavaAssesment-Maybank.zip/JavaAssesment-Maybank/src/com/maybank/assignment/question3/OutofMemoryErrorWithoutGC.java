package com.maybank.assignment.question3;

public class OutofMemoryErrorWithoutGC {
    public static void main(String[] args) {
        StringBuffer sb = new StringBuffer();
        try {
            for (int i = 0; i < Integer.MAX_VALUE; i++) {
                sb.append("Out of Memory Error occurred: Java heap space");
            }
        } catch (OutOfMemoryError e) {
            System.err.println("Out of Memory Error occurred: " + e.getMessage());
        }
    }
}

