package com.maybank.assignment.question4;

import com.maybank.assignment.model.MenuItem;

import java.util.*;

public class RestaurantMenu {

    public static void main(String[] args) {
        List<MenuItem> menu = new ArrayList<>();
        menu.add(new MenuItem("Burger", "Main Course", 5.99));
        menu.add(new MenuItem("Pizza", "Main Course", 8.99));
        menu.add(new MenuItem("Salad", "Appetizer", 4.99));
        menu.add(new MenuItem("Soup", "Appetizer", 3.99));
        menu.add(new MenuItem("Ice Cream", "Dessert", 2.99));

        Scanner scanner = new Scanner(System.in);

        try {
            System.out.println("Enter the sorting criteria (category, price, name): ");
            String searchCriteria = scanner.nextLine().trim().toLowerCase();

            switch (searchCriteria) {
                case "category":
                    menu.sort(Comparator.comparing(item -> item.getCategory()));
                    System.out.println("Menu sorted by category:");
                    break;

                case "price":
                    menu.sort(Comparator.comparingDouble(item -> item.getPrice()));
                    System.out.println("Menu sorted by price:");
                    break;

                case "name":
                    menu.sort(Comparator.comparing(item -> item.getName()));
                    System.out.println("Menu sorted by name:");
                    break;

                default:
                    System.out.println("Invalid input. Please select one of the following keywords to sort:\n1. category\n2. name\n3. price");
                    return;
            }

            menu.forEach(System.out::println);

        } finally {
            scanner.close();
        }
    }
}
