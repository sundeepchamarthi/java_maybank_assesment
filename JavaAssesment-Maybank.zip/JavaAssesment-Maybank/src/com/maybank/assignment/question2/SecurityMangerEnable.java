package com.maybank.assignment.question2;

import java.io.File;
import java.util.Formatter;
import java.util.Scanner;

public class SecurityMangerEnable{
    public static void main(String args[]) throws Exception{

        //enable Security manager in program level
        //System.setSecurityManager(new SecurityManager());

        try{
            //To Access Input file when disable above System.setSecurityManger method
            File file = new File("input.txt");
            Scanner scObj= new Scanner(file);
            System.out.println("File path:"+file.getAbsolutePath());
            int no1=scObj.nextInt();
            int no2=scObj.nextInt();

            System.out.println("The two nos are:"+no1+","+no2);

            //write to a file

            Formatter outObj=new Formatter(new File("output.txt"));
            int totalSum=no1+no2;
            System.out.println("The Total Sum value is:"+totalSum);
            outObj.format("%d",totalSum);
            outObj.close();

        }catch (Exception ee){
            System.out.println("Error::" + ee.toString());

        }
    }
}